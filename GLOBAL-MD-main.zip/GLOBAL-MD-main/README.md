### FIXED & UPDATED

--------

<p align="center">
<a href="https://github.com/GlobalTechInfo"><img title="Author" src="https://telegra.ph/file/78899ccfed9d3ec2fee61.jpg?style=for-the-badge&logo=github"></a>

GLOBAL-MD is a Cool Multi-Device WhatsApp bot developed by [GlobalTechInfo](https://github.com/GlobalTechInfo). It offers a wide range of extraordinary features, making it an advanced and user-friendly bot for various purposes.

<p align="center"><img src="https://profile-counter.glitch.me/{GLOBAL-MD}/count.svg" alt="Qasim Ali :: Visitor's Count" /></p>


--------


<p align="center">
<a href="https://github.com/GlobalTechInfo/followers"><img title="Followers" src="https://img.shields.io/github/followers/GlobalTechInfo?color=red&style=flat-square"></a>
<a href="https://github.com/GlobalTechInfo/GLOBAL-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/GlobalTechInfo/GLOBAL-MD?color=blue&style=flat-square"></a>
<a href="https://github.com/GlobalTechInfo/GLOBAL-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/GlobalTechInfo/GLOBAL-MD?color=red&style=flat-square"></a>
<a href="https://github.com/GlobalTechInfo/GLOBAL-MD/"><img title="Size" src="https://img.shields.io/github/repo-size/GlobalTechInfo/GLOBAL-MD?style=flat-square&color=green"></a>
<a href="https://github.com/GlobalTechInfo/GLOBAL-MD/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

### `INSTALLATION METHOD`
  
### Fork The Repo

--------
<a href="https://github.com/GlobalTechInfo/GLOBAL-MD/fork"><img title="GLOBAL-MD" src="https://img.shields.io/badge/FORK-GLOBAL MD-h?color=red&style=for-the-badge&logo=stackshare"></a>
--------|

### `GENERATE SESSION`


### PAIRING SERVER 1
--------
<a href='https://globalpair-code.onrender.com/' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/PAIRING CODE-1-green?style=for-the-badge&logo=opencv&logoColor=white'/></a>
--------|

### PAIRING SERVER 2
--------
<a href='https://replit.com/@tlptrends92/GLOBAL-SESSIONS#main.sh' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/PAIRING CODE-2-green?style=for-the-badge&logo=opencv&logoColor=white'/></a>
--------|


`GET CREDS FILE AND UPLOAD IT INSIDE SESSION FOLDER OF FORK`

--------


### `DEPLOYEMENTS`

### TUTORIAL FOR PANEL
<a href="https://youtu.be/WpfdClSeQyg"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/WpfdClSeQyg" /><br>

### BOT HOSTING PANEL LINK
<a href='https://bot-hosting.net/?aff=1097457675723341836' target="_blank"><img alt='Panel Link'
src='https://img.shields.io/badge/HOSTING%20PANEL-blue?style=for-the-badge&logo=Cloudflare&logoColor=white'/></a>

`AFTER YARN GET INSTALLED, REMOVE YOUR COMMAND FROM BASH FILE AND CHANGE BOT START FILE NAME FROM index.js TO start.js`

--------


### DEPLOY TO HEROKU 

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/GlobalTechInfo/GLOBAL-MD)

--------

### DEPLOY TO REPLIT

   <a href='https://repl.it/github/GlobalTechInfo/GLOBAL-MD' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-REPLIT-orange?style=for-the-badge&logo=replit&logoColor=white'/></a>

--------

### DEPLOY TO CODESPACE

<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/CODESPACE-h?color=navy&style=for-the-badge&logo=visualstudiocode'/></a></p>

--------

### DEPLOY TO RAILWAY

<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RAILWAY-h?color=black&style=for-the-badge&logo=railway'/></a></p>

--------

### TUTORIAL FOR RENDER
<a href="https://youtu.be/8Y8cE68vg5A"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/WpfdClSeQyg" /><br>

### DEPLOY TO RENDER

<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RENDER-h?color=maroon&style=for-the-badge&logo=render'/></a></p>

--------


### DEPLOY TO SCALINGO

<a href='https://auth.scalingo.com/users/sign_in' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/SCALINGO-h?color=olive&style=for-the-badge&logo=scalingo'/></a></p>

--------


### DEPLOY TO KOYEB

<a href='https://app.koyeb.com/auth/signin' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-KOYEB-blue?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

--------


# Thanks To 💚

| [![Qasim Ali](https://github.com/GlobalTechInfo.png?size=100)](https://github.com/GlobalTechInfo) | [![Suhail Ser](https://github.com/SuhailTechInfo.png?size=100)](https://github.com/SuhailTechInfo) | [![WhiskeySockets](https://github.com/WhiskeySockets.png?size=100)](https://github.com/WhiskeySockets) |
| --- | --- | ---|
| [Qasim Ali](https://github.com/GlobalTechInfo) | [Suhail Ser](https://github.com/SuhailTechInfo) | [WhiskeySockets](https://github.com/WhiskeySockets) |

--------

[![JOIN WHATSAPP CHANNEL](https://raw.githubusercontent.com/Neeraj-x0/Neeraj-x0/main/photos/suddidina-join-whatsapp.png)](https://whatsapp.com/channel/0029VagJIAr3bbVBCpEkAM07)

--------

### TUTORIAL FOR TERMUX/UBUNTU
<a href="https://youtu.be/-ZDLyq3FdvA"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/-ZDLyq3FdvA" /><br>

--------


### `COMMANDS FOR TERMUX/UBUNTU`
```bash
apt update && apt upgrade -y
pkg install proot-distro
proot-distro install ubuntu
proot-distro login ubuntu
apt update && apt upgrade -y
apt install -y webp git ffmpeg curl imagemagick
apt -y remove nodejs
curl -fsSl https://deb.nodesource.com/setup_lts.x | bash - && apt -y install nodejs
git clone https://github.com/<your gitHub Username>/GLOBAL-MD
cd GLOBAL-MD
npm install
npm start
```

--------


### Features 💌
### Scroll Right To Left
| Menu ⁠➜ | Bot | Group | Search | Download | Tools | Ai | Game | Fun | Owner | Bug | Convert | List |
| --------| --- | ----- | ------ | -------- | ----- | -- | ---- | --- | ----- | ----| --------| -----|
| Work ➜ |  ✅ |   ✅  |    ✅  |     ✅   |   ✅  | ✅ |   ✅ |  ✅ |  ✅   | ✅  |    ✅   |  ✅  |

| Menu ⁠➜ | Anime | Photo| Video | Database | Sticker | Stalker | Other |Religion | NSFW | 
| --------| ----- | ---- | ----- | -------- | ------- | ------- | ------|---------| -----|
| Work ➜ |   ✅  |   ✅ |   ✅  |    ✅    |    ✅   |    ✅   |   ✅  |    ✅   |  ✅  |

--------

## ♦️`Reminder`
   
## 
- This bot is not made by `WhatsApp Inc.` So misusing the bot might `ban` your `WhatsApp account!`(Though your WhatsApp account can be unbanned only once.)
- I am not responsible for banning your account.
- Use at your own risk by keeping this warning in mind.

 <br><br>
